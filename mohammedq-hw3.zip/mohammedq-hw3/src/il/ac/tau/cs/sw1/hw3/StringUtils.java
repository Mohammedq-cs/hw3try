package il.ac.tau.cs.sw1.hw3;

import java.util.Arrays;

public class StringUtils {

	public static String findSortedSequence(String str) {
		// TODO
		String [] words = str.split(" ");
		String [] ret = new String[words.length];
		String [] temp = new String[0];
		int cnt = 0;
		for (int i = 0; i < words.length; i++){
			if(words.length - 1 == i){
				ret[cnt] = words[i];
				break;
			}
			if (words[i].compareTo(words[i+1]) <=0){
				ret[cnt] = words[i];
				cnt++;
			}else {
				ret[cnt] = words[i];
				if (notNullCounter(temp) <= notNullCounter(ret)){
					temp = ret;
				}
				ret = new String[words.length];
				cnt = 0;
			}

		}
		if (notNullCounter(temp) <= notNullCounter(ret)){
			temp = ret;
		}

		return String.join(" ", removeNullElements(temp)); //Replace this with the correct returned value

	}

	public static boolean isAnagram(String a, String b) {
		// TODO
		char[] chST1 = StringUtils.sentenceToCharsConverter(a.toLowerCase(), true);
		char[] chST2 = StringUtils.sentenceToCharsConverter(b.toLowerCase(), true);
		Arrays.sort(chST1);
		Arrays.sort(chST2);
		return Arrays.equals(chST1, chST2);
	}
	
	public static boolean isEditDistanceOne(String a, String b){
		// TODO
		if(Math.abs(a.length() - b.length()) > 1){
			return false;
		}
		if(a.equals(b)){
			return true;
		}
		if (a.length() == b.length()){
			return editD(a,b);
		}

		if (a.length() > b.length()){
			return subString(a, b);
		}

		return subString(b, a);

	}

	private static boolean subString(String a, String b){ //Assume len(a) >= len(b)

		for (int i = 0; i < a.length(); i++){ // choosing the index that we don't want to include
			boolean bl = true;
			int cn = 0;
			for (int j = 0; j < b.length(); j++){
				if(j == i){ cn++; }
				if (a.charAt(cn) != b.charAt(j)){
					bl = false;
					break;
				}
				cn++;
			}
			if(bl){ return true;}
		}

		return false;

	}

	private static boolean editD(String a, String b){
		if (a.length() != b.length()){
			return false;
		}

		int cnt = 0;
		for (int i = 0; i < a.length(); i++){
			if(a.charAt(i) != b.charAt(i)){
				if(cnt == 0){
					cnt++;
				}
				else{
					return false;
				}
			}
		}

		return true;

	}

	private static char[] sentenceToCharsConverter(String str, boolean withoutSpace){
		int count = CharCounter(str, ' ');
		char[] chOfSentence = withoutSpace ? new char[str.length()- count]:new char[str.length()];
		int j = 0;
		for (int i = 0; i < str.length(); i++) {
			if (withoutSpace) {
				if (str.charAt(i) != ' ') {
					chOfSentence[j] = str.charAt(i);
					j++;
				}
			}else {
				chOfSentence[j] = str.charAt(i);
				j++;
			}

		}
		return chOfSentence;
	}

	private static int CharCounter(String st, char ch) {
		int count = 0;

		for (int i = 0; i < st.length(); i++) {
			if (st.charAt(i) == ch) {
				count++;
			}
		}
		return count;
	}

	private static int notNullCounter(String[] st) {
		int count = 0;

		for (String s : st) {
			if (s != null) {
				count++;
			}
		}
		return count;
	}

	private static String[] removeNullElements(String[] allElements) {
		// 1 : count
		int n = notNullCounter(allElements);

		// 2 : allocate new array
		String[] _localAllElements = new String[n];

		// 3 : copy not null elements
		int j = 0;
		for (String allElement : allElements)
			if (allElement != null)
				_localAllElements[j++] = allElement;

		return _localAllElements;
	}
}
