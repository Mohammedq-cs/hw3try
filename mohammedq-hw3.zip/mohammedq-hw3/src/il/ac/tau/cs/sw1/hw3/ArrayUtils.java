package il.ac.tau.cs.sw1.hw3;

public class ArrayUtils {

	public static int[][] transposeMatrix(int[][] m) {

		int [][] transposeMat = (m.length > 0) ? new int [m[0].length][m.length] : new int [0][];
		for (int j = 0; j < m.length; j++){
			for (int i = 0; i < m[0].length; i++){
				transposeMat[i][j] = m[j][i];
			}

		}
		return transposeMat;
	}

	public static int[] shiftArrayCyclic(int[] array, int move, char direction) {
		// TODO
		if(direction == 'R'){
			if(move > 0 && array.length > 0 && move % array.length > 0){
				shiftArrayRight(array, move % array.length);
			}
			else {
				if (array.length > 0) {
					int i = array.length - (Math.abs(move) % array.length);
					if (move < 0 && i > 0) {
						shiftArrayRight(array, i);
					}
				}
			}

		}else if (direction == 'L'){

			if(move > 0 && array.length > 0 && move % array.length > 0){
				shiftArrayRight(array, array.length - (Math.abs(move) % array.length));
			}
			else if (move < 0 && array.length > 0 && (Math.abs(move) % array.length) > 0){
				shiftArrayRight(array, Math.abs(move) % array.length);
			}

		}
		return array; //Replace this with the correct returned value

	}

	public static int alternateSum(int[] array) {
		int max_sum = 0;
		for (int i = 0; i < array.length; i++){
			for (int j = i + 2; j < array.length; j++){
				max_sum = Math.max(alternateSummersArr(array, i, j), max_sum);
			}
		}
		// TODO
		return max_sum; //Replace this with the correct returned value

	}

	public static int findPath(int[][] m, int i, int j, int k) {
		// TODO

		if (i == j && k == 0) {
			return 0;
		}

		if (i == j && k == 1) {
			return 1;
		}

		int x = findPathHelpVer2(m, i, j, k);
		if (x == 1){
			return 1;
		}
		return 0;
	}

	private static void shiftArrayRight(int [] arr, int shift){
		int [] help = new int[shift];
		int [] help2 = new int[arr.length - shift];
		if (help.length >= 0) System.arraycopy(arr, arr.length - shift, help, 0, help.length);
		if (help2.length >= 0) System.arraycopy(arr, 0, help2, 0, help2.length);
		for(int i = 0; i < arr.length; i++){
			if(i < shift){ arr[i] = help[i]; }
			else { arr[i] = help2[i - shift]; }
		}
	}

	private static int alternateSummersArr(int [] arr, int start, int end){
		int h = 1;
		int sum = 0;
		for (int i = start; i < end+1; i++){
			sum += (h* arr[i]);
			h *= -1;
		}
		return sum;
	}

	private static int findPathHelpVer2(int[][] mat, int i, int j, int k){
		if (i != j && k == 0){
			return 0;
		}
		if (i == j && k == 0){
			return 1;
		}

		if (i == j && k > 0){
			return 2;
		}

		boolean gotOne = false;

		for (int index = 0; index < mat[i].length; index++){
			if (mat[i][index] == 1 && index != i){
				if ((findPathHelpVer2(mat, index, j, k-1)) == 1) {
					gotOne = true;
				}
				if ((findPathHelpVer2(mat, index, j, k-1)) == 2) {
					return 2;
				}
			}
		}
		if (gotOne){
			return 1;
		}
		return 0;
	}
}



